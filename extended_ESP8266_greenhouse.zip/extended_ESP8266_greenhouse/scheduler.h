#pragma once
bool timeToPublish();