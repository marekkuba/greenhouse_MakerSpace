#pragma once

void controlTick();