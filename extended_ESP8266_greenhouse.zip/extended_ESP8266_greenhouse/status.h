#pragma once
void logStatusIfNeeded();