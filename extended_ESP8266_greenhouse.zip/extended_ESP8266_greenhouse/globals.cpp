#include "config.h"
#include "model.h"
#include "mappings.h"
#include "persistence.h"
#include "mqtt.h"
#include "network.h"
#include "sensors_if.h"
#include <Ticker.h>

SensorManager Sensors;
NetworkConfig netConfig;
Greenhouse greenhouse;
std::vector<ParamBinding> bindings;
std::vector<DeviceConfig> devices;

std::function<void(void)> applyPersistedTargetsToModel = [](){};
WiFiEventHandler wifiConnectHandler;
WiFiEventHandler wifiDisconnectHandler;
AsyncMqttClient mqttClient;
Ticker wifiReconnectTimer;
Ticker mqttReconnectTimer;

//const unsigned long PUBLISH_INTERVAL = 10000;
unsigned long previousMillis = 0;
//const uint8_t NO_PIN = 255;
