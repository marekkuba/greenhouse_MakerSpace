#pragma once
bool ensureMqttConnected();